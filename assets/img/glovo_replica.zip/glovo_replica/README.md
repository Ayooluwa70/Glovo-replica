# GloClone frontend replica

This is a beginner-friendly Glovo-style delivery marketplace project.

## Main pages
- index.html — responsive homepage
- pages/search.html — search/filter page
- pages/restaurant.html — restaurant/menu page
- pages/cart.html — shopping cart
- pages/checkout.html — checkout
- pages/orders.html — orders placeholder
- pages/favourites.html — favourites placeholder
- pages/profile.html — profile placeholder
- pages/rider.html — rider page
- pages/business.html — business page
- pages/careers.html — careers page
- pages/about.html — about page
- pages/help.html — help page

## JavaScript
- location dropdown + saved location
- mobile navigation
- search
- category filtering
- cart using localStorage
- quantity controls
- checkout demo
- geolocation permission request

## Assets
Put your existing Logo.png and other images inside assets/img/.
