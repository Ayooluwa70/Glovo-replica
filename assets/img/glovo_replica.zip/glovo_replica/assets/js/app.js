
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

function closeMenus(except){
  $$(".location-menu,.profile-menu").forEach(m => { if(m !== except) m.classList.remove("open"); });
}

const locationBtn = $("#locationBtn");
const locationMenu = $("#locationMenu");
if(locationBtn && locationMenu){
  locationBtn.addEventListener("click", e => { e.stopPropagation(); closeMenus(locationMenu); locationMenu.classList.toggle("open"); });
  locationMenu.querySelectorAll("[data-location]").forEach(btn => {
    btn.addEventListener("click", () => {
      const text = $("#locationText");
      if(text) text.textContent = btn.dataset.location;
      locationMenu.classList.remove("open");
      localStorage.setItem("deliveryLocation", btn.dataset.location);
    });
  });
}
const savedLocation = localStorage.getItem("deliveryLocation");
if(savedLocation && $("#locationText")) $("#locationText").textContent = savedLocation;

const profileBtn = $("#profileBtn"), profileMenu = $("#profileMenu");
if(profileBtn && profileMenu){
  profileBtn.addEventListener("click", e => { e.stopPropagation(); closeMenus(profileMenu); profileMenu.classList.toggle("open"); });
}
document.addEventListener("click", () => closeMenus(null));

const menuBtn = $("#menuBtn"), mobileMenu = $("#mobileMenu");
if(menuBtn && mobileMenu) menuBtn.addEventListener("click", () => mobileMenu.classList.toggle("open"));

const profileModal = $("#loginModal");
if(profileBtn && profileModal){
  profileBtn.addEventListener("dblclick", () => profileModal.classList.add("open"));
}
if($("#modalClose")) $("#modalClose").addEventListener("click", () => profileModal.classList.remove("open"));
if(profileModal) profileModal.addEventListener("click", e => { if(e.target === profileModal) profileModal.classList.remove("open"); });

const heroSearch = $("#heroSearch");
if(heroSearch) heroSearch.addEventListener("submit", e => {
  e.preventDefault();
  const value = $("#heroSearchInput").value.trim();
  window.location.href = "pages/search.html" + (value ? "?q=" + encodeURIComponent(value) : "");
});

if($("#currentLocation")) $("#currentLocation").addEventListener("click", () => {
  if(!navigator.geolocation){ alert("Geolocation is not supported by this browser."); return; }
  navigator.geolocation.getCurrentPosition(
    () => { if($("#locationText")) $("#locationText").textContent = "Current location"; locationMenu?.classList.remove("open"); },
    () => alert("Location access was not allowed. You can choose an address manually.")
  );
});

function updateCartCount(){
  const cart = JSON.parse(localStorage.getItem("cart") || "[]");
  const count = cart.reduce((sum,item)=>sum + item.qty,0);
  $$("#cartCount").forEach(el => el.textContent = count);
}
updateCartCount();
