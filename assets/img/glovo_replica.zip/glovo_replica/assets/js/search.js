
const params = new URLSearchParams(location.search);
const searchInput = $("#searchInput");
const cards = [...$$(".searchable")];
const emptyState = $("#emptyState");
let activeFilter = params.get("category") || "all";
if(activeFilter === "food") activeFilter = "food";
if(searchInput && params.get("q")) searchInput.value = params.get("q");

function renderStores(){
  const query = (searchInput?.value || "").toLowerCase().trim();
  let visible = 0;
  cards.forEach(card => {
    const name = card.dataset.name.toLowerCase();
    const category = card.dataset.category;
    const matchesText = !query || name.includes(query);
    const matchesFilter = activeFilter === "all" || category.includes(activeFilter);
    const show = matchesText && matchesFilter;
    card.style.display = show ? "" : "block";
    if(!show) card.style.display = "none";
    if(show) visible++;
  });
  if(emptyState) emptyState.classList.toggle("hidden", visible !== 0);
  $$(".filter").forEach(btn => btn.classList.toggle("active", btn.dataset.filter === activeFilter));
}
$$(".filter").forEach(btn => btn.addEventListener("click",()=>{ activeFilter=btn.dataset.filter; renderStores(); }));
if($("#searchForm")) $("#searchForm").addEventListener("submit",e=>{e.preventDefault();renderStores()});
if(searchInput) searchInput.addEventListener("input",renderStores);
cards.forEach(card=>card.addEventListener("click",()=>{localStorage.setItem("selectedStore",card.dataset.name);location.href="restaurant.html"}));
renderStores();
