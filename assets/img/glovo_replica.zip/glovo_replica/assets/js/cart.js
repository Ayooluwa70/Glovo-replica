
function getCart(){ return JSON.parse(localStorage.getItem("cart") || "[]"); }
function saveCart(cart){ localStorage.setItem("cart", JSON.stringify(cart)); updateCartCount(); }

function addToCart(name,price){
  const cart=getCart();
  const existing=cart.find(x=>x.name===name);
  if(existing) existing.qty++;
  else cart.push({name,price:Number(price),qty:1});
  saveCart(cart);
  const toast=$("#toast");
  if(toast){toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),1200);}
}
$$(".add-product").forEach(btn=>btn.addEventListener("click",()=>addToCart(btn.dataset.name,btn.dataset.price)));

function renderCart(){
  const box=$("#cartItems"), empty=$("#cartEmpty");
  if(!box) return;
  const cart=getCart();
  if(!cart.length){box.innerHTML=""; if(empty) empty.style.display="block"; return;}
  if(empty) empty.style.display="none";
  box.innerHTML=cart.map((item,i)=>`<div class="cart-item"><div><h3>${item.name}</h3><p>₦${item.price.toLocaleString()}</p></div><div class="qty"><button data-minus="${i}">−</button><b>${item.qty}</b><button data-plus="${i}">+</button><strong>₦${(item.price*item.qty).toLocaleString()}</strong></div></div>`).join("");
  const subtotal=cart.reduce((s,x)=>s+x.price*x.qty,0), delivery=subtotal?1000:0, total=subtotal+delivery;
  if($("#subtotal")) $("#subtotal").textContent="₦"+subtotal.toLocaleString();
  if($("#delivery")) $("#delivery").textContent="₦"+delivery.toLocaleString();
  if($("#total")) $("#total").textContent="₦"+total.toLocaleString();
  if($("#checkoutTotal")) $("#checkoutTotal").textContent="₦"+total.toLocaleString();
  $$("[data-minus]").forEach(b=>b.onclick=()=>changeQty(Number(b.dataset.minus),-1));
  $$("[data-plus]").forEach(b=>b.onclick=()=>changeQty(Number(b.dataset.plus),1));
}
function changeQty(i,amount){
  const cart=getCart(); cart[i].qty+=amount;
  if(cart[i].qty<=0) cart.splice(i,1);
  saveCart(cart); renderCart();
}
renderCart();

const checkoutForm=$("#checkoutForm");
if(checkoutForm) checkoutForm.addEventListener("submit",e=>{
  e.preventDefault();
  if(!getCart().length){alert("Your cart is empty.");return;}
  localStorage.setItem("lastOrder", JSON.stringify(getCart()));
  localStorage.removeItem("cart");
  $("#successModal")?.classList.add("open");
});
